//alert dari app.js
alert('Ini Dari App.Js')

//confirm dari app.js
confirm('Apa Benar Dari App.Js ?')

//console.log
console.log('Ini Benar Console.log dari App.js yaa xixi') 


//variabel javascript
//var, let, const

let a = 1
let b = 3
let c = a + b

console.log(c)

//menampilkan tanggal
//Date()
//let tanggal = Date()
//alert(tanggal)

document.getElementById('Tanggal').innerHTML = tanggal
document.getElementById('Jam').innerHTML = jam


//DOM Selector HTML
//Document Object Model
//cara 1
//DOM HTML
let nama = 'Seliesca Whidya'
document.getElementById('nama').innerHTML = nama

//cara 2 
//document.getElementById('nama').innerHTML = 'Seliesca Whidya'

//DOM CSS
document.getElementById('nama').style.color = 'Blue'
document.getElementById('nama').style.backgroundColor = 'Black'

document.getElementById('nim').style.color = 'Blue'

function ubahwarna(){
   
    document.getElementById('nim').style.backgroundColor = 'Black'

}




